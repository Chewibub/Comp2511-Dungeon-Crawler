package unsw.dungeon.entity;

public enum State {
    ON, OFF,
}