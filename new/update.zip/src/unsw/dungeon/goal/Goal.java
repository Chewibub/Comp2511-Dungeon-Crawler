package unsw.dungeon.goal;

public interface Goal {
    boolean completed();
}
