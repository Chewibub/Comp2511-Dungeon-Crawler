package unsw.dungeon;

public interface GoalInterfaceOld {
    
    public void updateGoal();
	
}