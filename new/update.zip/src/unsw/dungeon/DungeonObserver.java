package unsw.dungeon;

public interface DungeonObserver {
	public void update();
	// public Entity getEntity();
}